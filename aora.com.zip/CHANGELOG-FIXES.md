# گزارش اصلاحات پروژه AORA

این فایل خلاصه‌ای از تمام باگ‌ها و اصلاحاتی است که روی پروژه انجام شد.

## 🔴 مشکلات بحرانی بک‌اند (که اصلاً اجازه build نمی‌دادند)

1. **فایل پروژه (`.csproj`) وجود نداشت** — بدون آن، بک‌اند اصلاً قابل build نبود. ساخته شد: `backend/Aora.csproj` با تمام پکیج‌های لازم (EF Core SqlServer, JwtBearer, BCrypt).
2. **`appsettings.json` با نام اشتباه ذخیره شده بود** (`backendappsettings.json`) — ASP.NET Core فقط `appsettings.json` را خودکار می‌خواند؛ تغییر نام داده شد.
3. **ناسازگاری Namespace در سراسر پروژه** — نیمی از فایل‌ها از `Aora` و نیمی از `Aoura` استفاده می‌کردند (`AoraDbContext` در واقع کلاسش `AouraDbContext` بود، `Page.cs`/`SiteSettings.cs`/`PagesController.cs`/`SettingsController.cs` از `Aoura.*` استفاده می‌کردند). همه چیز یکدست شد روی `Aora`.
4. **مدل `Meeting` اصلاً وجود نداشت** ولی `AoraDbContext` و `MeetingController` به آن ارجاع می‌دادند. ساخته شد: `backend/Models/Meeting.cs`.
5. **`CourseController.GetAll()` بریده/خراب بود** (`public async Task c.Description.Contains(q));`) — کاملاً بازنویسی شد؛ حالا فیلتر، جستجو و نام‌گذاری فیلدها دقیقاً با چیزی که `courses.html` انتظار دارد یکی است.
6. **`AuthService.cs` فقط یک متد شناور بدون کلاس/using بود** — کاملاً بازنویسی شد (Register, Login, GenerateToken با JWT واقعی).
7. **`AuthController` یک `[Route]` خراب داشت** (`[Route SigningCredentials(key, ...)]` — احتمالاً محتوای دو فایل قاطی شده بود) — اصلاح شد.
8. **`AdminController.GetStats()` بریده بود** و متدهای مدیریت کاربران (`GetUsers`, `DeleteUser`) گم شده بودند — بازنویسی و تکمیل شد.
9. **`ForumController.GetAll()`** پروجکشن `Select` برای replies بریده بود — اصلاح شد.
10. **JSON casing اشتباه بود** (`JsonNamingPolicy.Null`) — یعنی بک‌اند فیلدها را با حروف بزرگ (`Title`, `Price`) برمی‌گرداند ولی فرانت‌اند انتظار camelCase (`title`, `price`) دارد. تغییر داده شد به `JsonNamingPolicy.CamelCase`.
11. **`[Authorize]` هیچ‌جا کار نمی‌کرد** چون `Program.cs` هرگز Authentication/JWT را پیکربندی نکرده بود (`AddAuthentication`, `UseAuthentication`, `UseAuthorization` هیچ‌کدام وجود نداشتند) — اضافه شد.
12. **`MapFallback` فقط یک کامنت خالی بود** — حالا واقعاً صفحات داینامیک (`Page` entity از پنل ادمین) را رندر می‌کند و در غیر این صورت به `index.html` هدایت می‌کند.
13. **فایل‌های استاتیک فرانت‌اند اصلاً سرو نمی‌شدند** به شکل درست — به‌جای کپی شکننده به wwwroot، مستقیماً پوشه فرانت‌اند سرو می‌شود.

## 🆕 قابلیت‌های جدید بک‌اند (فاز ۶ و ۷)

- `EnrollmentController.cs` — لیست دوره‌های من، بررسی ثبت‌نام، ثبت‌نام مستقیم (دوره رایگان)، به‌روزرسانی پیشرفت.
- `PaymentController.cs` — شروع و تایید پرداخت (در حالت آزمایشی چون کلید واقعی زرین‌پال موجود نیست؛ کامنت‌گذاری شده که چطور با درگاه واقعی جایگزین شود).
- `CourseController` حالا CRUD کامل دارد (Create/Update/Delete) محدود به نقش admin/professor — قبلاً هیچ endpoint ای برای «ادمین دوره اضافه کند» وجود نداشت.

## 🟡 مشکلات فرانت‌اند

1. **`js/ajax.js` یک `demoHandler` تکراری و خراب در بالای فایل داشت** (کد مرده) — حذف شد.
2. **ناسازگاری کلید‌های localStorage**: بخشی از کد از `aora_user`/`aora_users`/`aora_cart` و بخشی دیگر از `aoura_user`/`aoura_users`/`aoura_cart` استفاده می‌کرد — یعنی دو سیستم داده کاملاً جدا از هم. همه یکدست شدند روی `aoura_*` (پیروی از قرارداد غالب در باقی فایل‌ها). کلید `aora_courses` که در همه‌جا سازگار بود دست‌نخورده باقی ماند.
3. **`Payment.updateProgress()` در `app.js` تعریف نشده بود** ولی `dashboard-student.html` آن را صدا می‌زد (خطای JS هنگام تکمیل یک درس). اضافه شد.
4. **`cart.html` تابع `renderCartPage()` را صدا می‌زد ولی این تابع هیچ‌جا تعریف نشده بود** — یعنی سبد خرید همیشه خالی نمایش داده می‌شد. کاملاً پیاده‌سازی شد (نمایش آیتم‌ها، حذف، جمع مبلغ، تسویه‌حساب).
5. **`course-single.html` (صفحه اختصاصی دوره) اصلاً وجود نداشت** — با اینکه از `courses.html`، `index.html` و `dashboard-professor.html` به آن لینک داده می‌شد (۴۰۴ همیشگی روی «مشاهده دوره»). صفحه کامل ساخته شد: هیرو، کارت خرید sticky، آکاردئون سرفصل‌ها، دوره‌های مرتبط.
6. **`course-study.html` هم اصلاً وجود نداشت** (لینک «ادامه یادگیری») — به‌جای ساخت یک صفحه تکراری، لینک‌ها به `dashboard-student.html?course=ID` تغییر کردند و آن صفحه طوری اصلاح شد که با `?course=` مستقیم به تب محتوای همان دوره برود (این تب از قبل به‌طور کامل و درست پیاده‌سازی شده بود).
7. **`faq.html` وجود نداشت** ولی از فوتر تقریباً همه صفحات سایت لینک داده می‌شد — صفحه سوالات متداول ساخته شد.

## 🔄 مهاجرت به PHP خالص (حذف ASP.NET)

backend ASP.NET (C#) به‌طور کامل حذف شد و تمام عملکردها به PHP منتقل شد:

- **`api/settings.php`** — endpointهای جدید اضافه شد:
  - `POST /api/settings/logo` — آپلود لوگو با محدودیت حجم و فرمت
  - `PUT /api/settings/header` — ذخیره هدر گلوبال (HTML/CSS/GrapesJS)
  - `PUT /api/settings/footer` — ذخیره فوتر گلوبال
  - `GET /api/settings/render/{slug}` — رندر صفحه کامل با هدر/فوتر گلوبال
  - `GET /api/settings/render-home` — رندر صفحه اصلی
  - پشتیبانی از `maintenanceMode` و `faviconUrl` در PUT تنظیمات
- **`api/index.php`** — بررسی حالت تعمیرات (maintenance mode) اضافه شد. اگر `maintenance_mode` در دیتابیس فعال باشد، فقط ادمین‌ها اجازه دسترسی دارند.
- **تابع `buildFullPageHtml()`** — معادل PHP کلاس `PageRenderer.cs` در `settings.php` پیاده‌سازی شد.
- تمام endpointهای ASP.NET قبلاً در PHP موجود بودند و فقط endpointهای تنظیمات تکمیل شدند.

## ⚠️ محدودیت‌ها و کارهای باقی‌مانده (مهم)

- **من دسترسی به .NET SDK یا SQL Server ندارم**، پس نتوانستم واقعاً `dotnet build` یا `dotnet ef migrations add` را اجرا کنم. تمام اصلاحات از طریق بازبینی دقیق کد (بررسی تعادل آکولادها، سینتکس، namespaceها) انجام شده، ولی توصیه می‌کنم بعد از دریافت پروژه، این دستورات را اجرا کنید:
  ```
  cd backend
  dotnet restore
  dotnet ef migrations add InitialCreate
  dotnet ef database update
  dotnet run
  ```
- **فرانت‌اند در حالت Demo کار می‌کند** (`config.demoMode = true` در `js/ajax.js`) و مستقیماً به بک‌اند واقعی وصل نیست؛ صفحات login/register هم اصلاً از API استفاده نمی‌کنند (کاملاً client-side با localStorage). این باعث شد بتوانم سایت را بدون نیاز به سرور واقعی تحویل بدهم و همچنان کار کند. **وقتی خواستید به بک‌اند واقعی وصل شوید**، توجه کنید که مسیرهای API فرانت‌اند (مثل `/courses`) با مسیرهای واقعی بک‌اند (`/api/course`) یکی نیستند — این هماهنگ‌سازی نیاز به یک مرحله جداگانه دارد که عمداً انجامش ندادم چون بدون امکان تست واقعی، ریسک خراب کردن نسخه فعلاً کارآمد دمو را داشت.
- سرفصل‌ها (`Chapters`) در بک‌اند به‌صورت JSON درون خود جدول `Course` ذخیره می‌شوند (نه جدول‌های جدا `Chapter`/`Lesson`) — برای سادگی و تطابق با ساختار داده‌ی موجود در فرانت‌اند دمو. اگر بعداً به یک curriculum engine کاملاً نرمال‌شده نیاز داشتید، این بخش قابل ارتقاست.
